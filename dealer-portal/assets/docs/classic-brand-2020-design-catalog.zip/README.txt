2020 Design / CAD Catalog Files

Placeholder package — replace assets/docs/classic-brand-2020-design-catalog.zip with the published catalog files.
